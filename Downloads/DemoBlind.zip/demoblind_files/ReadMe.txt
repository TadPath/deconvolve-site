*******************************************************************************
*              ReadMe file for the www.deconvolve.net DemoBlind               *
**             ================================================              **
*                          P.J.Tadrous 28.05.2010                             *
*******************************************************************************

Terms of Use
------------
THIS DEMO AND ALL ASSOCIATED FILES AND SOFTWARE ARE PROVIDED 'AS IS' AND
WITHOUT WARRANTY OF ANY KIND. IF YOU CHOSE TO USE THIS DEMO YOU DO SO AT YOUR
OWN RISK. 


Introduction
------------
The files and images in this demo are provided to demonstrate the use of the
BiaQIm IP Suite blind deconvolution program DeconBMI.exe and the GUI display
program CLViewer.exe. This demo requires that you have first instaled the
BiaQIm IP Suite software which is freely available via www.bialith.com.


How to Run the Demo
-------------------
To run the demo on MS Windows simply double-click the batch file DemoBMI.bat.
If you are running this on Linux using WINE then run the batch file via WINE but
the GUI display of the progress of the deconvolution will not (or may not) work
so you will only see the stats updating on the command window. However, the
deconvolution will (or at least is should) still work and you should get the
result images at the end. You should be able to see the updating display of the
intermediate images as the deconvolution progresses if you run an equivalent
command on your native Linux terminal assuming you have installed the BIPS for
Linux on your machine. 


What's in the Demo
------------------
Truth         A folder containing the ground truth image and PSF (FITS format).
DCBMI.set     This is the settings file for the blind deconvolution program.
DCSetImg.txt  The template settings file for the image refinement cycles.
DCSetPSF.txt  The template settings file for the PSF refinement cycles.
ImgCycles.txt Definition of how many image refinement cycles per iteration.
PSFCycles.txt Definition of how many image refinement cycles per iteration.
ImgConv.fit   The input vlurred image (in FITS format)
PSFPrior.fit  The input prior guess at a PSF (FITS format): just a blank square
DemoBMI.bat   The batch file that contains the command-line instruction to run
              the program.    
ReadMe.txt    This ReadMe file


How Does it All Work?
---------------------
By double-clicking the DemoBMI.bat file you call up a command-processor window
that calls the program DeconBMI.exe. DeconBMI.exe in turn reads in DCBMI.set,
ImgConv.fit, PSFPrior.fit, ImgCycles.txt, PSFCycles.txt and uses these files
together with DCSetImg.txt and DCSetPSF.txt to call the program Deconvolve.exe
in alternating cycles to refine the PSF estimate and the image estimate given
the input image and current estimates of image solution and PSF.
While this is happening, DeconBMI keeps track of the number of iterations and
at intervals determined via the settings file it outputs display BMP images of
the current solutions and residuals graph and calls CLViewer.exe to display
them.
While the program is running various temproary files may appear in your folder
but these should automatically be deleted at the end (if the program is not
terminated prematurely) to leave you with the following result files:

ImgDBCMI.tsv      The results log file showing the settings and residuals at
                  each iterate and giving timing information.
ImgDBCMI_Img.dou  The resulting deconvolved image solution (raw doubles format)
ImgDBCMI_Img.qih  The external header file for the deconvolved image solution
ImgDBCMI_PSF.fit  The resulting PSF solution  (raw doubles format).
ImgDBCMI_PSF.qih  TThe external header file for the PSF solution.

The commandline structure for DeconBMI.exe is this:

DeconBMI.exe <datatype> <height> <width> <Depth> <image|list> <outdatatype>
 <outroot> <settings_file> 

The command-line instruction contain in DemoBMI.bat is this:

DeconBMI.exe fit 1 1 1 ImgConv.fit fit ImgDBCMI DCBMISet.txt

As the input image is of a headed type (in this case, FITS) there is no need to
specify the height and width properly because this information is read from the
FITS header. This is why 1 1 1 can be used for <height> <width> <Depth>. If we
were using a raw data type such as .dou then we would need to specify these
explicitly as in the following example:

DeconBMI.exe dou 64 64 1 ImgConv.dou fit ImgDBCMI DCBMISet.txt

Also note that the output data type will be raw doubles format even though we
have specified 'fit' becuase, in the current version of DeconBMI this argument
is ignored (but it must be supplied). 



Viewing the Results
-------------------
Assuming all has worked well you will have the results displayed for you in
CLViewer windows. However these are just BMP versions of the results which are
actually saved as raw doubles images (double precision floating). To view these
use BiaQIm - just drag-n-drop the fits files into BiaQIm (as the user's manual
describes). The PSF file will look black unless you first click the 'Stretch'
box in the Input/Output tab before loading the image.


Where to go from Here
---------------------
Assuming all has worked well you should probably read the user's manual for
background information before proceeding (at least the introductory chapters
and the sections on Deconvolve, DeconBMI and CLViewer.
Open the settings file DCBMI.set in a text editor and you will see suggestions
at the bottom of it for altering the settings. Try altering them then re-run
the demo. Finally you can experiment with different input images and other
settings. Visit www.deconvolve.net to look for updates and share your
experiences on the user's forum. Happy deconvolving!


PJT 2010 - 2024
