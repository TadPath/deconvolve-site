DeconBMI.exe fit 1 1 1 ImgConv.fit fit ImgDBCMI DCBMISet.txt
