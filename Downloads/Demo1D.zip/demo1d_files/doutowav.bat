del %1.wav
xtox d 1 16384 %1.dou c _tmpaudio.raw 0 0 1
Sox -r 11025 -b 8 -e unsigned -c 1 _tmpaudio.raw %1.wav
del _tmpaudio.raw
del _tmpaudio.qih