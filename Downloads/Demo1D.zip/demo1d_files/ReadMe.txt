*******************************************************************************
*              ReadMe file for the www.deconvolve.net    Demo1D               *
**             ================================================              **
*                          P.J.Tadrous 28.05.2010                             *
*******************************************************************************

Terms of Use
------------
THIS DEMO AND ALL ASSOCIATED FILES AND SOFTWARE ARE PROVIDED 'AS IS' AND
WITHOUT WARRANTY OF ANY KIND. IF YOU CHOSE TO USE THIS DEMO YOU DO SO AT YOUR
OWN RISK.
This demo also includes an MS Windows executable called WavtoRaw.exe that is
heavily based on source code authored by WolfCoder and then modified and
compiled by myself for this demo. This is not part of the standard
BiaQIm Image Processing Suite but is provided here for the purposes of this
demo and is provided 'as is' without warranty of any kind.


Additional Requirement
----------------------
To run this demo you will need to have the The SoundExchange Open Source program
called 'sox' properly installed on your system and on your PATH. You can get sox
from here: https://sourceforge.net/projects/sox/files/sox/ 
Sox is used in the scripts of this demo to convert the results into a .wav file
so you can easily listen to it.
Without sox, you can still perform the convolution and deconvolution on the
sound file by modifying the scripts in this demo but you will not be able to
hear the convolved or deconvolved result unless you can find some other way to
convert the raw data files generated and used in this demo into usable audio
format files.


Introduction
------------
The files in this demo are provided to demonstrate the use of the BiaQIm IP
Suite for both convolving (i.e. blurring or slurring) a 1D signal which, in
this case is a .wav sound file. You wil then also use the BiaQIm IP suite to
deconvolve it in an attempt to restore the original unslurred sound.
This demonstrates the use of the commandline to run the programs Convolve.exe
and Deconvolve.exe
This demo requires that you have first instaled the BiaQIm IP Suite software
which is freely available via www.deconvolve.net.


How to Run the Demo
-------------------
WARNING: THIS IS AN ADVANCED USER DEMO. The other demos in this series
(DemoBlind and Demo3D) can be run by simply double-clicking on a batch file.
However, this sound file demo requires you to issue commands from a Windows
command console so is more involving. You do not 'run' this demo, rather you
follow the Step-by-Step Guide described below. This should not be the first demo
you try if you are unfamilar with the command line. 
In addition to the files included in this demo and the programs installed in
the BiaQIm IP Suite, you will probably want to listen to the sound files used
in this demo so you will want a media player that can play .wav files. I use
'MS Sound Recorder' accessory on MS Windows because it is standard on MS Windows
PCs and less bulky than Windows Media Player for just listening to simple small
wav files.


What's in the Demo
------------------
Apollo01.wav  The original sound file you will work on.
SoundPSF.qck  The 1D convolution kernel (PSF) you will use to blur it.
ConvSet.txt   The convolution settings file.
DCSet.txt     The deconvolution settings file.
doutowav.bat  A batch file that uses sox.exe and the Biaram program xtox.exe to
              convert a raw doubles array into a .wav formatted sound file.
              NOTE: This is not a general conversion batch file but was 
              specifically written for this demo. You will need to alter the
              instructions within it if you want to use it for converting files
              other than the specific ones involved in this demo.
rawtowav.bat  A batch file that uses sox.exe to convert a raw PCM-type sound
              file into a .wav formatted sound file.
              NOTE: This is not a general conversion batch file but was 
              specifically written for this demo. You will need to alter the
              instructions within it if you want to use it for converting files
              other than the specific ones involved in this demo.
WavtoRaw.exe  The .wav to raw doubles converter program based on the WolfCoder
              source code referred to in the Terms of Use above.
REadMe.txt    This ReadMe file.



Step-by-Step Guide
------------------

0. Raise a command prompt (cmd.exe) and cd to the directory where the files are.

1. Convert the original wav file to raw unsigned char format:
WavtoRaw Apollo01.wav

2. Convolve the original by the PSF:
Convolve c 1 16384 1 Apollo01.uch d SoundConv.dou ConvSet.txt

3. Convert this convolved signal to wav and listen to it
doutowav SoundConv

[Now, optionally, load SoundConv.wav into an audio player such as Microsoft's
 'Sound Recorder' so you can hear what it sounds like]

4. Deconvolve the convolved signal using the same PSF:
Deconvolve d 1 16384 1 SoundConv.dou c SoundDeconvolved.uch DCSet.txt
[This will run for 512 iterations - takes about 20 seconds on a 32bit 3GHz P4]

5. Convert this deconvolved signal to wav and listen to it
rawtowav SoundDeconvolved
[Now load SoundDeconvolved.wav into an audio player]



Where to go from Here
---------------------
Assuming all has worked well you should probably read the user's manual for
background information before proceeding (at least the introductory chapters
and the sections on Convolve, Deconvolve and XtoX, You should also read the SoX
user's manual available from the SoX website http://sox.sourceforge.net/
if you intend to continue working with other sound files or you want to alter
the batch files supplied with this demo.
You will then be in a position to start tinkering with the settings and can
experiment with different input files and kernels.
Visit www.deconvolve.net to look for updates and share your experiences on the
user's forum. Happy deconvolving!


PJT 2010 - 2024
