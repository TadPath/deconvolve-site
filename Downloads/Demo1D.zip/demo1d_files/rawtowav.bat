del %1.wav
copy %1.uch _tmpaudio.raw
Sox -r 11025 -b 8 -e unsigned -c 1 _tmpaudio.raw %1.wav
del _tmpaudio.raw
del _tmpaudio.qih