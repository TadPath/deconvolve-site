*******************************************************************************
*              ReadMe file for the www.deconvolve.net    Demo3D               *
**             ================================================              **
*                          P.J.Tadrous 28.05.2010                             *
*******************************************************************************

Terms of Use
------------
THIS DEMO AND ALL ASSOCIATED FILES AND SOFTWARE ARE PROVIDED 'AS IS' AND
WITHOUT WARRANTY OF ANY KIND. IF YOU CHOSE TO USE THIS DEMO YOU DO SO AT YOUR
OWN RISK.


Introduction
------------
The files and images in this demo are provided to demonstrate the use of the
BiaQIm IP Suite deconvolution program Deconvolve.exe and the GUI display
program CLViewer.exe. This demo requires that you have first instaled the
BiaQIm IP Suite software which is freely available via www.deconvolve.net.


How to Run the Demo
-------------------
To run the demo simply double-click the batch file Demo3D.bat.
If all goes well this will run 64 iterations of a 3D Lucy-Richardson
deconvolution and give you visual GUI updates with each iteration. This whole
process takes about 13 minutes to complete on a 3.0GHz Pentium 4 single core
machine and required about 300 MB of free RAM.
The input volume is 128x128x128 voxels in size.
If you are running this on Linux using WINE then run the batch file via WINE but
the GUI display of the progress of the deconvolution will not (or may not) work
so you will only see the stats updating on the command window. However, the
deconvolution will (or at least is should) still work and you should get the
result images at the end. You should be able to see the updating display of the
intermediate images as the deconvolution progresses if you run an equivalent
command on your native Linux terminal assuming you have installed the BIPS for
Linux on your machine.


What's in the Demo
------------------
PSF           A folder containing the 3D PSF as a stack of raw doubles 2D
              images and a qfl file.
VolBlur       A folder containing the 3D blurred input volume as a stack of
              FITS formatted 2D images and a qfl file. The images are stored
              in double precision floating point format.
VolOrig       A folder containing the original unblurred 3D volume as a stack
              of 8bpp BMP 2D images and a qfl file. This is provided so you can 
              compare this with the results of the deconvolution but this is
              not needed or used in the deconvolution process.
DCSet3D.txt   The deconvolution settings file.
VolBlur.qfl   A list file pointing to the blurred volume.
PSF3D.qfl     A list file pointing to the 3D PSF.
Demo3D.bat    The batch file that contains the command-line instruction to run
              the program.    
ReadMe.txt    This ReadMe file


How Does it All Work?
---------------------
By double-clicking the Demo3D.bat file you call up a command-processor window
that calls the program Deconvolve.exe. Deconvolve.exe in turn reads in
DCSet3D.txt and the blurred volume and 3D PSF (using VolBlur.qfl and PSF3D.qfl)
and performs the iterative deconvolution as the settings file dictates.
While this is happening, Deconvolve keeps track of the number of iterations and
at intervals determined via the settings file it outputs display BMP images of
the current solution and residuals graph and calls CLViewer.exe to display
them. Only one slice through the solution volume is displayed and this slice is
determined via the settings file (it is XZ slice number 93 in this demo but
this can be altered by changing the settings file).
While the program is running various temproary files may appear in your folder
but these should automatically be deleted at the end (if the program is not
terminated prematurely) to leave you with the following result files:

VolDC.tsv      The results log file showing the settings and residuals at        
               each iterate and giving timing information.
VolDC.qfl      A list file pointing to the deconvolved volume.
VolDC_###.bmp  A set of 128 2D images (in 8bpp greyscale BMP format) numbered
               from 000 to 127 (replacing ###). These make up the deconvolved
               3D volume.

The commandline structure for Deconvolve.exe is this:

Deconvolve.exe  <datatype> <height> <width> <Depth> <image|list> <outdatatype>
 <outimage|root> <settings_file>

The command-line instruction contain in Demo3D.bat is this:

Deconvolve.exe fit 128 128 128 VolBlur.qfl b8 VolDC DCSet3D.txt

As the input image is of a headed type (in this case, FITS) there is no need to
specify the height and width exactly because this information is read from the
FITS header. There is also no need to specify the depth exactly (as long as we
set it to 2 or more to let Deconvolve know this is a 3D case). So, we could
alternatively have run it with this instruction toget the same resutt:

Deconvolve.exe fit 1 1 2 VolBlur.qfl b8 VolDC DCSet3D.txt


Viewing the Results
-------------------
Assuming all has worked well you will have one slice from the resulting
deconvolved volume displayed for you in a CLViewer window. However, to see or
examine the whole volume you will need to lead it into a suitable program. One
example is BiaQIm where you can just drag-n-drop the VolDC.qfl file into BiaQIm
(as the user's manual describes) and explore all the slices in the volume that
way.


Where to go from Here
---------------------
Assuming all has worked well you should probably read the user's manual for
background information before proceeding (at least the introductory chapters
and the sections on Deconvolve and CLViewer.
You will then be in a position to start tinkering with the settings and can
experiment with different input volumes (and 3D PSFs).
Visit www.deconvolve.net to look for updates and share your experiences on the
user's forum. Happy deconvolving!


PJT 2010 - 2024
